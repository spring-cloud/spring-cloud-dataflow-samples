# Standalone Stream Samples

## Building the apps

```bash
$./mvnw clean package
```

## Building the distribution

```bash
$./mvnw package -Pdist

```

This must be run from this directory and will build  `dist/usage-cost-stream-rabbit.zip` 