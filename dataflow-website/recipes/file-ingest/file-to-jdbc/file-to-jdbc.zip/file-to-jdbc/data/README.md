Sample Data
---

This directory contains data for use with file ingest samples.

`name-list.csv` contains over 5000 randomly generated names written as `first`,`last`.

The `split` directory contains the same data split into 100+ files.
