# Standalone Stream Samples

## Building the apps

```bash
$./mvnw clean package
```

## Building the distribution

```bash
$./mvnw verify -Pdist

```

This must be run from this directory and will build  `dist/usage-cost-rabbit.zip` 